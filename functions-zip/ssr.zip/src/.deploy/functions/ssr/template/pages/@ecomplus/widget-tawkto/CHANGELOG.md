# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.1.8](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-tawkto@1.1.7...@ecomplus/widget-tawkto@1.1.8) (2020-12-16)

**Note:** Version bump only for package @ecomplus/widget-tawkto





## [1.1.7](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-tawkto@1.1.6...@ecomplus/widget-tawkto@1.1.7) (2020-12-15)

**Note:** Version bump only for package @ecomplus/widget-tawkto





## [1.1.6](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-tawkto@1.1.5...@ecomplus/widget-tawkto@1.1.6) (2020-12-15)

**Note:** Version bump only for package @ecomplus/widget-tawkto





## [1.1.5](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-tawkto@1.1.4...@ecomplus/widget-tawkto@1.1.5) (2020-10-26)

**Note:** Version bump only for package @ecomplus/widget-tawkto





## [1.1.4](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-tawkto@1.1.3...@ecomplus/widget-tawkto@1.1.4) (2020-07-29)

**Note:** Version bump only for package @ecomplus/widget-tawkto





## [1.1.3](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-tawkto@1.1.2...@ecomplus/widget-tawkto@1.1.3) (2020-07-17)

**Note:** Version bump only for package @ecomplus/widget-tawkto





## [1.1.2](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-tawkto@1.1.1...@ecomplus/widget-tawkto@1.1.2) (2020-05-05)

**Note:** Version bump only for package @ecomplus/widget-tawkto





## [1.1.1](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-tawkto@1.1.0...@ecomplus/widget-tawkto@1.1.1) (2020-05-03)

**Note:** Version bump only for package @ecomplus/widget-tawkto





# 1.1.0 (2020-05-03)


### Features

* **tawkto:** storefront plugin for tawk.to chat ([8e55439](https://github.com/ecomplus/storefront/commit/8e554397b96e396799806a347f3de2e30b58feb8))
